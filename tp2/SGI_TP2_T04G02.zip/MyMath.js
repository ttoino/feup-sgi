export function degreesToRadians(degrees) {
    return (degrees * Math.PI) / 180;
}
